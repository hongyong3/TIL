# 모듈 import 우선순위
# 1. 파이썬 표준 라이브러리 ex) os random...
# 2. core django : 장고 프레임워크에 내장되어 있는 것.
# 3. 3rd party library : pip로 설치한 것들. ex) django-extension
# 4. 장고 프로젝트 app ex) from .models import Board

from django.shortcuts import render, redirect
from .models import Board

# Create your views here.
def index(request):
    # boards = Board.objects.all()[::-1]  # 원래 결과를 파이썬이 변경
    boards = Board.objects.order_by('-id')  # db가 애초에 정렬을 바꿔서 보내주는 것
    return render(request, 'boards/index.html', {'boards':boards})
    
def new(request):
    return render(request, 'boards/new.html')
    
def create(request):
    title = request.POST.get('title')
    content = request.POST.get('content')
    
    # 저장하는 방법 1) 앞으로 이것을 씀
    board = Board(title=title, content=content)
    board.save()
    
    # 저장하는 방법 2)
    # Board.objects.create(title=title, content=content)
    
    return redirect('/boards/') # 방법 1
    # return redirect(index))   # 방법 2
    
    # 처음에 글이 보이지 않았던 이유는 보여지는 페이지 자체를 index이지만 index의 url로는 돌아가지 못해기 때문이다. 즉, 단순히 html 문서만 보여준 것이다.
    # create는 model에 record를 생성해~!! 라는 요청이기 때문에, 단순히 페이지를 달라고 하는 GET방식보다는 POST가 의미상 더 적절하다.create
    # (그리고 모델과 관련된 데이터이기 때문에 url에 직접 보여진 것은 좋지 않다.)
    
def detail(request, pk):
    board = Board.objects.get(pk=pk)
    return render(request, 'boards/detail.html', {'board': board})
    
def delete(request, pk):
    board = Board.objects.get(pk=pk)
    board.delete()
    return redirect('/boards/')
    
def edit(request, pk):
    board = Board.objects.get(pk=pk)
    return render(request, 'boards/edit.html', {'board': board})
    
def update(request, pk):
    board = Board.objects.get(pk=pk)
    board.title = request.POST.get('title')
    board.content = request.POST.get('content')
    board.save()
    return redirect(f'/boards/{ board.pk }/')