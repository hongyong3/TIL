from django.db import models

# Create your models here.
class Board(models.Model):   # 각 모델은 django.db.models.Model 클래스의 서브 클래스로 표현된다.
    title = models.CharField(max_length=10)    # 'max_length'는 charfield의 필수인자다.
    content = models.TextField()    # 제한이 없다. 만약 제한을 두고 싶지 않으면 TextField을 쓰고, 제한을 두고싶으면 CharField를 쓴다.
    created_at = models.DateTimeField(auto_now_add=True)    # auto_now_add=True : 장고 모델이 최초저장시에만 현재 날짜를 적용
    updated_at = models.DateTimeField(auto_now=True)        # auto_now=True : 장고 모델이 save 될 때 마다 현재날짜로 갱신.
    
    def __str__(self):
        return f"{self.id}: {self.title}"