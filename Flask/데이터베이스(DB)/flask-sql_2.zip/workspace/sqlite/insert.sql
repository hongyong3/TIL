INSERT INTO classmate (name, age, address)
VALUES('안 상 현', 43, '대전');
INSERT INTO classmate (name, age, address)
VALUES('신 채 원', 15, '서울');
INSERT INTO classmate (name, age, address)
VALUES('안 상 현', 43, '대전');
INSERT INTO classmate (name, age, address)
VALUES('신 채 원', 15, '서울');

