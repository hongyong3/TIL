-- 15workshop
CREATE TABLE bands (
-- AUTOINCREMENT는 INTEGER에서만 사용할 수 있따.
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
debut INTEGER
);

INSERT INTO bands(name, debut)
VALUES('Queen', 1973), ('Coldplay', 1231), ('MCR', 2001);

SELECT id, name FROM bands;
SELECT name FROM bands WHERE debut < 2000;