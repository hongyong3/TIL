from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# table 만들기
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False) 
    # String(80)은 스트링은 80으로 제한을 둔다. unique=True는 중복은 안된다. nullable=False는 빈공간은 안된다.
    email = db.Column(db.String(120), unique=True, nullable=False)
    
    def __repr__(self):
        return f"<User '{self.username}'>" # 무엇이 추가되었는지 알아보기 편하도록하기 위해서