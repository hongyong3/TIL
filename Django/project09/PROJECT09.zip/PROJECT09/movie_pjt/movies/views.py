from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from .models import Movie, Score
from .forms import ScoreForm

# Create your views here.
def list(request):
    movies = Movie.objects.all()
    scores = Score.objects.all()
    context = {
        'movies' : movies, 
        'scores' : scores,
    }
    return render(request, 'movies/list.html', context)
    
def detail(request, movie_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    score_form = ScoreForm()
    context = {
        'movie' : movie,
        'score_form' : score_form,
    }
    return render(request, 'movies/detail.html', context)

@login_required
@require_POST    
def score_create(request, movie_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    score_form = ScoreForm(request.POST)
    if score_form.is_valid():
        score = score_form.save(commit=False)
        score.user = request.user
        score.movie = movie
        score.save()
        return redirect('movies:detail', movie_pk)
    return redirect('movies:detail', movie_pk)

@login_required
@require_POST      
def score_delete(request, movie_pk, score_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    form = ScoreForm(request.POST)
    if request.user != score.user:
        return redirect('movies:detail', movie_pk, score_pk)
    score.delete()
    return redirect('movies:detail', movie_pk, score_pk)