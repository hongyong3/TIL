from django.shortcuts import render, HttpResponse
from random import randint
import random
from datetime import datetime
# from pprint import pprint

# Create your views here.
def index(request):
    # print(request)
    # print(type(request))
    # pprint(request.META)
    # return HttpResponse('Welcome to Django !')
    return render(request, 'home/index.html')
    
# def dinner(request):
#     menus = ['참 치 회', '참 치 찌 깨', '참 지 초 밥']
#     return HttpResponse(menus[randint(0,2)])

def dinner(request):
    menus = ['참 치 회', '참 치 찌 깨', '참 치 초 밥']
    pick = random.choice(menus)
    return render(request, 'home/dinner.html', {'menus' : menus, 'pick' : pick})

def hello(request, name):
    return render(request, 'home/hello.html', {'name' : name})
    
def cube(request, num):
    nummm = int(num) **3
    return render(request, 'home/cube.html', {'num' : num, 'nummm': nummm})
    
def ping(request):
    return render(request, 'home/ping.html')
    
def pong(request):
    print(request.GET)
    data = request.GET.get('data')
    return render(request, 'home/pong.html', {'data':data})
    

def user_new(request):
    return render(request, 'home/user_new.html') 
    
def user_create(request):
    nickname = request.POST.get('nickname')
    password = request.POST.get('password')
    return render(request, 'home/user_create.html', {'nickname': nickname, 'password': password})
    
def template_example(request):
    my_list = ['짜장면', '탕수육', '짬뽕', '양장피']
    my_sentence = 'Life is short, you need pytho'
    messages = ['apple', 'banana', 'cucumber', 'mango']
    empty_list = []
    datetimenow = datetime.now()
    return render(request, 'home/template_example.html',
                {'my_list': my_list, 'my_sentence': my_sentence,
                 'messages': messages, 'empty_list': empty_list,
                 'datetimenow': datetimenow
                })
                
def static_example(request):
    return render(request, 'home/static_example.html')