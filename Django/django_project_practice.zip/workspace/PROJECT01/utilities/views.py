from django.shortcuts import render
from datetime import datetime, timedelta
import os
import requests

# Create your views here.
time_now = datetime.now()
def index(request):
    return render(request, 'utilities/index.html')
    
def bye(request):
    time_bye = datetime(2019, 2, 28, 18, 00, 0)
    # time_now = datetime.now()
    time_d_day = time_bye - time_now
    return render(request, 'utilities/bye.html', {'time_bye': time_bye, 'time_now':time_now, 'time_d_day':time_d_day})
    
def graduation(request):
    time_bye2 = datetime(2019, 5, 28, 18, 00, 0)
    time_d_day2 = time_bye2 - time_now
    return render(request, 'utilities/graduation.html', {'time_bye2': time_bye2, 'time_now':time_now, 'time_d_day2':time_d_day2})
    
def imagepick(request):
    # img = requests.GET.get("https://picsum.photos/500/500/?random")
    return render(request, 'utilities/imagepick.html')
    
def today(request):
    key = os.getenv("KEY")
    base_url = "https://api.openweathermap.org/data/2.5/weather?q=Daejeon,kr&lang=kr&APPID="
    url = base_url + key
    url = requests.get(url).json()
    description = url["weather"][0]["description"]
    temp_min = url["main"]["temp_min"]-273.15
    temp_max = url["main"]["temp_max"]-273.15
    return render(request, 'utilities/today.html', {'key':key, 'base_url':base_url, 'url':url, 'description':description, 'temp_min':temp_min, 'temp_max':temp_max})
    
def ascii_new(request):
    fonts = ['short', 'utopia', 'rounded', 'acrobatic', 'alligator']
    return render(request, 'utilities/ascii_new.html', {'fonts':fonts})
    
def ascii_make(request):
    text = request.GET.get('text')
    base_url = 'http://artii.herokuapp.com/make?text='
    url = base_url + text
    url = requests.get(url)
    text2= url.text
    return render(request, 'utilities/ascii_make.html', {'text':text, 'base_url':base_url, 'url':url, 'text2': text2})
    
def original(request):
    return render(request, 'utilities/original.html')
    
def translated(request):
    text = request.GET.get('text')
    naver_client_id = 'OuXKowJg6szN7l65GCXA'
    naver_client_secret = 'cTotrkhIGk'
    
    papago_url = "https://openapi.naver.com/v1/papago/n2mt"
    # 네이버에 Post 요청을 위해서 필요한 내용들
    headers = {
        "X-Naver-Client-Id": naver_client_id,
        "X-Naver-Client-Secret": naver_client_secret
    }
    data = {
        "source": "ko",
        "target": "en",
        "text": text[:]
    }
    papago_response = requests.post(papago_url, headers=headers, data=data).json()
    print(papago_response)
    reply_text = papago_response["message"]["result"]["translatedText"]
    return render(request, 'utilities/translated.html', {'reply_text': reply_text})