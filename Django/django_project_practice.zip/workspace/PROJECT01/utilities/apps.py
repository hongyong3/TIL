from django.apps import AppConfig


class UtilitiesConfig(AppConfig):
    name = 'utilities'
