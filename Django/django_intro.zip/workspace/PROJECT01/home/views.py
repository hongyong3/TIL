from django.shortcuts import render, HttpResponse
from random import randint
import random
# from pprint import pprint

# Create your views here.
def index(request):
    # print(request)
    # print(type(request))
    # pprint(request.META)
    return HttpResponse('Welcome to Django !')
    
# def dinner(request):
#     menus = ['참 치 회', '참 치 찌 깨', '참 지 초 밥']
#     return HttpResponse(menus[randint(0,2)])

def dinner(request):
    menus = ['참 치 회', '참 치 찌 깨', '참 치 초 밥']
    pick = random.choice(menus)
    return render(request, 'dinner.html', {'menus' : menus, 'pick' : pick})

def hello(request, name):
    return render(request, 'hello.html', {'name' : name})
    
def cube(request, num):
    nummm = int(num) **3
    return render(request, 'cube.html', {'num' : num, 'nummm': nummm})
    
def ping(request):
    return render(request, 'ping.html')
    
def pong(request):
    print(request.GET)
    data = request.GET.get('data')
    return render(request, 'pong.html', {'data':data})
    

def user_new(request):
    return render(request, 'user_new.html') 
    
def user_create(request):
    nickname = request.POST.get('nickname')
    password = request.POST.get('password')
    return render(request, 'user_create.html', {'nickname': nickname, 'password': password})