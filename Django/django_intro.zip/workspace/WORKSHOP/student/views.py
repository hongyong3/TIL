from django.shortcuts import render

# Create your views here.
def info(request):
    return render(request, 'info.html')
    
def student(request, name):
    students = {'홍길동': 22, '김길동':23, '박길동':24}
    name = name
    return render(request, 'student.html', {'name':name, 'age':students[name]})