from django import forms
from .models import Review

class ReviewForm(forms.ModelForm):
    score = forms.IntegerField(min_value=1, max_value=10)
    content = forms.CharField(label="")
    class Meta:
        model = Review
        fields = ['score', 'content',]
        widgets = {
            'content': forms.TextInput(attrs={'size': '100',})
        }