from django.contrib import admin
from .models import Movie, Genre, Actor, Review, Director

# Register your models here.
class MovieAdmin(admin.ModelAdmin):
    list_display = ('pk', 'title', 'poster_path',)
    
admin.site.register(Movie, MovieAdmin)
admin.site.register(Genre)
admin.site.register(Actor)
admin.site.register(Review)
admin.site.register(Director)