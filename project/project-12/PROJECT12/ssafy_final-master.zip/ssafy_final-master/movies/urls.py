from django.urls import path
# from rest_framework_swagger.views import get_swagger_view
from . import views

app_name = 'movies'
urlpatterns = [
    # path('director/<int:director_pk>', views.director_profile),
    # path('actor/<int:actor_pk>', views.actor_profile),
    # path('genre/<int:genre_pk>', views.genre_detail),
    # path('movies/<int:movie_pk>', views.movie_detail),
    # path('docs/', get_swagger_view(title='Api Docs')),
    path('director/<int:director_pk>/followD', views.followD, name='followD'),
    path('actor/<int:actor_pk>/followA', views.followA, name='followA'),
    path('<int:movie_pk>/review_delete/<int:review_pk>', views.review_delete, name='review_delete'),
    path('<int:movie_pk>/review_create/', views.review_create, name='review_create'),
    path('genre/<int:genre_pk>', views.genre_detail, name='genre'),
    path('director/<int:director_pk>', views.director_profile, name='director'),
    path('actor/<int:actor_pk>', views.actor_profile, name='actor'),
    path('<int:movie_pk>', views.movie_detail, name='movie_detail'),
    path('', views.movies_list, name='list'),
]