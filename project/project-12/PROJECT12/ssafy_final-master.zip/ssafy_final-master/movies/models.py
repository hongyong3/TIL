from django.db import models
from django.conf import settings

# Create your models here.
class Genre(models.Model):
    name = models.TextField()
    
    def __str__(self):
        return self.name
        

class Director(models.Model):
    name = models.TextField()
    img = models.TextField(null=True, blank=True)
    
    def __str__(self):
        return self.name
        
class Actor(models.Model):
    name = models.TextField()
    img = models.TextField(null=True, blank=True)
    
    def __str__(self):
        return self.name
        
class Movie(models.Model):
    title = models.TextField()
    poster_path = models.TextField(blank=True)
    genres = models.ManyToManyField('Genre', related_name="movies")
    overview = models.TextField(blank=True)
    release_date = models.TextField(blank=True)
    directors = models.ManyToManyField('Director', related_name="movies", blank=True)
    actors = models.ManyToManyField('Actor', related_name="movies",  blank=True)
    
    def __str__(self):
        return self.title
        
class Review(models.Model):
    score = models.IntegerField()
    content = models.TextField()
    movie = models.ForeignKey(Movie, related_name="reviews", on_delete = models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True)
    
    def __str__(self):
        return  f'{self.score} | {self.content}'