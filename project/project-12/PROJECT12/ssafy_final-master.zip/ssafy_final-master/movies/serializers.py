from .models import Genre, Movie, Review, Director, Actor
from rest_framework import serializers
 
class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['id', 'movie_id', 'score', 'content']
    
class MovieSerializer(serializers.ModelSerializer):
    class Meta:
        model = Movie
        fields = ['id','title', 'poster_path']

class GenreDetailSerializer(serializers.ModelSerializer):
    movies = serializers.StringRelatedField(many=True)
    class Meta:
        model = Genre
        fields = ['id', 'name', 'movies']

class ActorSerializer(serializers.ModelSerializer):
    movies = serializers.StringRelatedField(many=True)
    class Meta:
        model = Actor
        fields = ['id', 'name', 'img', 'movies']

class DirectorSerializer(serializers.ModelSerializer):
    movies = serializers.StringRelatedField(many=True)
    class Meta:
        model = Director
        fields = ['id', 'name', 'img', 'movies']

class MovieDetailSerializer(serializers.ModelSerializer):
    acting = serializers.StringRelatedField(many=True)
    genres = serializers.StringRelatedField(many=True)
    directing = serializers.StringRelatedField(many=True)
    reviews = serializers.StringRelatedField(many=True)
    class Meta:
        model = Movie
        fields = ('id', 'title', 'poster_path', 'overview', 'release_date', 'directing', 'acting', 'genres', 'review_set')

