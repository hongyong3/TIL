from django.shortcuts import render, redirect, get_object_or_404, get_list_or_404
from .models import Movie, Genre, Director, Actor, Review
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from .serializers import DirectorSerializer, ActorSerializer, GenreDetailSerializer, MovieSerializer, MovieDetailSerializer
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from .forms import ReviewForm
# Create your views here.

# api
# @api_view(['GET'])
# def movies_list(request):
#     movies = Movie.objects.all()
#     serializer = MovieSerializer(movies, many=True)
#     return Response(serializer.data)

# @api_view(['GET'])
# def movie_detail(request, movie_pk):
#     movie = get_object_or_404(Movie, pk=movie_pk)
#     serializer = MovieDetailSerializer(movie)
#     return Response(serializer.data)

# @api_view(['GET'])
# def genre_detail(request, genre_pk):
#     genre = get_object_or_404(Genre, pk=genre_pk)
#     serializer = GenreDetailSerializer(genre)
#     return Response(serializer.data)

# @api_view(['GET'])
# def actor_profile(request, actor_pk):
#     actor = get_object_or_404(Actor, pk=actor_pk)
#     serializer = ActorSerializer(actor)
#     return Response(serializer.data)
    
# @api_view(['GET'])
# def director_profile(request, director_pk):
#     director = get_object_or_404(Director, pk=director_pk)
#     serializer = DirectorSerializer(director)
#     return Response(serializer.data)
    
#------------------------------------------end api

def movies_list(request):
    topmovie = get_object_or_404( Movie, pk=4)
    topmovies = Movie.objects.all()[2:7]
    movies = Movie.objects.all()
    context = {
        'topmovie':topmovie,
        'topmovies':topmovies,
        'movies' : movies
    }
    return render(request, 'movies/list.html', context)

@login_required    
@require_POST
def review_create(request, movie_pk):
    form = ReviewForm(request.POST)
    if form.is_valid():
        review = form.save(commit=False)
        review.user = request.user
        review.movie_id = movie_pk
        review.save()
        return redirect('movies:movie_detail', movie_pk)
       
@login_required    
@require_POST
def review_delete(request, movie_pk, review_pk):
    review = get_object_or_404(Review, pk=review_pk)
    if review.user != request.user:
        return redirect('movies:movie_detail', movie_pk)
    review.delete()
    return redirect('movies:movie_detail', movie_pk) 
        
def movie_detail(request, movie_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    reviews = movie.reviews.all()
    reviewl = 1
    if len(reviews): reviewl = len(reviews)
        
    reviewsum = 0
    for review in reviews:
        reviewsum += review.score
    reviewavg = round(reviewsum/reviewl, 2)
    review_form = ReviewForm()
    context = { 'movie' : movie,
                'form' : review_form,
                'reviewavg' : reviewavg
    }
    return render(request, 'movies/movie_detail.html', context)
    
def actor_profile(request, actor_pk):
    people = get_object_or_404(Actor, pk=actor_pk)
    temp = people.movies.all()
    scores = []
    for i, movie in enumerate(temp):
        reviews = movie.reviews.all()
        reviewl = 1
        if len(reviews): reviewl = len(reviews)
        reviewsum = 0
        for review in reviews:
            reviewsum += review.score
        reviewavg = round(reviewsum/reviewl, 2)
        scores.append([reviewavg, i])
    scores.sort()
    scores.reverse()
    movies = []
    for score in scores:
        movies.append([temp[score[1]], score[0]])
    context = {'people' : people,
                'movies': movies
    }
    return render(request, 'movies/actor.html', context)

def director_profile(request, director_pk):
    people = get_object_or_404(Director, pk=director_pk)
    temp = people.movies.all()
    scores = []
    for i, movie in enumerate(temp):
        reviews = movie.reviews.all()
        reviewl = 1
        if len(reviews): reviewl = len(reviews)
        reviewsum = 0
        for review in reviews:
            reviewsum += review.score
        reviewavg = round(reviewsum/reviewl, 2)
        scores.append([reviewavg, i])
    scores.sort()
    scores.reverse()
    movies = []
    for score in scores:
        movies.append([temp[score[1]], score[0]])
    context = {'people' : people,
                'movies': movies
    }
    return render(request, 'movies/director.html', context)

def genre_detail(request, genre_pk):
    genre = get_object_or_404(Genre, pk=genre_pk)
    temp = genre.movies.all()
    scores = []
    for i, movie in enumerate(temp):
        reviews = movie.reviews.all()
        reviewl = 1
        if len(reviews): reviewl = len(reviews)
        reviewsum = 0
        for review in reviews:
            reviewsum += review.score
        reviewavg = round(reviewsum/reviewl, 2)
        scores.append([reviewavg, i])
    scores.sort()
    scores.reverse()
    movies = []
    for score in scores:
        movies.append([temp[score[1]], score[0]])
    context = {'genre' : genre,
                'movies': movies
    }
    return render(request, 'movies/genre.html', context)
    
@login_required
def followA(request, actor_pk):
    people = get_object_or_404(Actor, pk=actor_pk)
    #people이 팔로워하고 있는 모든 유저에 현재 접속 유저가 있다면, 
    #언팔, 아니면 팔로우
    if request.user in people.followings.all():
        people.followings.remove(request.user)
    else:
        people.followings.add(request.user)
    return redirect('movies:actor', actor_pk)

@login_required
def followD(request, director_pk):
    people = get_object_or_404(Director, pk=director_pk)
    #people이 팔로워하고 있는 모든 유저에 현재 접속 유저가 있다면, 
    #언팔, 아니면 팔로우
    if request.user in people.followings.all():
        people.followings.remove(request.user)
    else:
        people.followings.add(request.user)
    return redirect('movies:director', director_pk)