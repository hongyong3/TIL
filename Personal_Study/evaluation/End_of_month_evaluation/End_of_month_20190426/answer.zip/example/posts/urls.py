from django.urls import path
from . import views

app_name='posts'

urlpatterns = [
    path('like_post/<int:post_pk>', views.like_post, name='like_post'),
    path('delete/<int:post_pk>', views.delete, name='delete'),
    path('edit/<int:post_pk>', views.edit, name='edit'),
    path('create/', views.create, name='create'),
    path('list/', views.list, name='list'),
]