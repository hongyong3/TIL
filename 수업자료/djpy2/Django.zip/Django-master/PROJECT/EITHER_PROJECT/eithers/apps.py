from django.apps import AppConfig


class EithersConfig(AppConfig):
    name = 'eithers'
