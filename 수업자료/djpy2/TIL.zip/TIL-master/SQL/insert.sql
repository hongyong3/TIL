INSERT INTO classmate (name, age, address)
VALUES('안상현', 43, '대전');
INSERT INTO classmate (name, age, address)
VALUES ('신채원', 15, '서울');
