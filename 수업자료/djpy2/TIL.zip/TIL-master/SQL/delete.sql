-- 보통 값을 지울 때는 유니크한 값인 id 를 지운다.
DELETE FROM classmate WHERE id=3;