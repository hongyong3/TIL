CREATE TABLE users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
first_name TEXT,
last_name TEXT,
age INTEGER,
country TEXT,
phone TEXT,
balance INTEGER );