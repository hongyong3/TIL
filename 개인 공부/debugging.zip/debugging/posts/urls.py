from django.urls import path, include
from . import views

appname='posts'

urlpatterns = [
    path('delete/<int:post_pk>/<int:comment_pk>/', views.delete_comment, name='delete_comment'),
    path('create_comment/<int:post_pk>/', views.create_comment, name='create_comment'),
    path('delete/<int:post_pk>/', views.delete, name='delete'),
    path('update/<int:post_pk>/', views.edit, name='edit'),
    path('create/', views.create, name='create'),
    path('<int:pk>/', views.detail, name='detail'),
    path('', views.list, name='list'),
]