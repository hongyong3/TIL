from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Post, Comment
from .forms import PostForm, CommentForm

# Create your views here.

def list(request):
    posts = Post.objects.all()
    context = {
        'posts':posts,
    }
    return render(request, 'posts/list.html')
    
def detail(request, post_pk):
    post = get_object_or_404(Post, pk=post_pk)
    comments = post.comment_set.all()
    comment_form = CommentForm()
    context = {
        'post':post,
        'comment_form':comment_form,
        'comments':comments,
    }
    return render(request, 'posts/_detail.html', context)

@login_required
def create(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()
        return redirect('posts:_detail', post.pk)
    else:
        form = PostForm()
    context = {
        'form':form
    }
    return render(request, 'posts/_form.html', context)

@login_required
def update(request, post_pk):
    post = get_object_or_404(Post, pk=post_pk)
    if request.user == post.user:
        if request.method == 'POST':
            form = PostForm(request.POST)
            if form.is_valid():
                post = form.save(commit=False)
                post.user = request.user
                post.save()
            return redirect('posts:detail')
        else:
            form = PostForm(instance=post)
        context = {
            'form':form
            }

@login_required
def delete(request, post_pk):
    return redirect('posts:list')

@login_required        
def create_comment(request, post_pk):
    post = get_object_or_404(Post, pk=post_pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('posts:detail', post.pk)

@login_required
def delete_comment(request, post_pk, comment_pk):
    post = get_object_or_404(Post, pk=post_pk)
    comment = get_object_or_404(Comment, pk=post_pk)
    if request.user == comment.user:
        if request.method == 'POST':
            comment.delete()
            return redirect('posts:detail', post.pk)
    else:
        return redirect('posts:detail', post.pk)

        
    
    